let mode = "register";
let csrf = "";
let currentUser = null;
const $ = id => document.getElementById(id);
function message(text, error = false) {
  $("status").textContent = text;
  $("status").classList.toggle("error", error);
}
async function getCsrf() {
  const r = await fetch("/api/auth/csrf", { credentials: "same-origin" });
  const d = await r.json(); csrf = d.csrfToken;
}
async function api(url, method = "GET", body = null) {
  const options = { method, credentials: "same-origin", headers: {} };
  if (body !== null) {
    options.headers["Content-Type"] = "application/json";
    options.headers["X-CSRF-Token"] = csrf;
    options.body = JSON.stringify(body);
  }
  const r = await fetch(url, options);
  const d = await r.json().catch(() => ({}));
  if (d.csrfToken) csrf = d.csrfToken;
  if (!r.ok) throw new Error(d.error || "تعذر إكمال الطلب.");
  return d;
}
function setMode(next) {
  mode = next;
  $("formTitle").textContent = mode === "register" ? "إنشاء حساب جديد" : "تسجيل الدخول";
  $("formHint").textContent = mode === "register" ? "كلمة المرور 12 حرفًا على الأقل وتحتوي على حرف إنجليزي ورقم." : "أدخل بيانات حسابك.";
  $("nameWrap").classList.toggle("hidden", mode !== "register");
  $("name").required = mode === "register";
  $("password").autocomplete = mode === "register" ? "new-password" : "current-password";
  $("password").minLength = mode === "register" ? 12 : 1;
  $("submitBtn").textContent = mode === "register" ? "إنشاء الحساب" : "دخول";
  $("toggleBtn").textContent = mode === "register" ? "لدي حساب بالفعل" : "إنشاء حساب جديد";
}
function renderUser(user) {
  currentUser = user;
  $("authForm").classList.add("hidden");
  $("profile").classList.remove("hidden");
  $("profile").className = "profile";
  $("profile").textContent = `مرحبًا ${user.name} — ${user.email} — الدور: ${user.role === "admin" ? "مدير" : "مستخدم"}`;
  $("logoutBtn").classList.remove("hidden");
  $("adminRefresh").classList.toggle("hidden", user.role !== "admin");
  $("adminLock").classList.toggle("hidden", user.role === "admin");
  $("adminPanel").classList.toggle("hidden", user.role !== "admin");
  if (user.role === "admin") loadAdmin().catch(e => message(e.message, true));
}
function renderLoggedOut() {
  currentUser = null;
  $("authForm").classList.remove("hidden");
  $("profile").classList.add("hidden");
  $("logoutBtn").classList.add("hidden");
  $("adminRefresh").classList.add("hidden");
  $("adminPanel").classList.add("hidden");
  $("adminLock").classList.remove("hidden");
  setMode("register");
}
$("toggleBtn").addEventListener("click", () => { setMode(mode === "register" ? "login" : "register"); message(""); });
$("authForm").addEventListener("submit", async e => {
  e.preventDefault();
  $("submitBtn").disabled = true;
  message("جارٍ المعالجة...");
  try {
    const body = { name: $("name").value, email: $("email").value, password: $("password").value };
    const d = await api(`/api/auth/${mode}`, "POST", body);
    $("password").value = "";
    renderUser(d.user);
    message(mode === "register" ? "تم إنشاء الحساب." : "تم تسجيل الدخول.");
  } catch (err) { message(err.message, true); }
  finally { $("submitBtn").disabled = false; }
});
$("logoutBtn").addEventListener("click", async () => {
  try { await api("/api/auth/logout", "POST", {}); renderLoggedOut(); await getCsrf(); message("تم تسجيل الخروج."); }
  catch (e) { message(e.message, true); }
});
$("setupForm").addEventListener("submit", async e => {
  e.preventDefault();
  $("setupStatus").textContent = "جارٍ إنشاء حساب المدير...";
  try {
    const d = await api("/api/setup-admin", "POST", {
      name: $("adminName").value, email: $("adminEmail").value,
      password: $("adminPassword").value, setupToken: $("setupToken").value
    });
    $("setupStatus").textContent = d.message;
    $("adminPassword").value = ""; $("setupToken").value = "";
  } catch (err) { $("setupStatus").textContent = err.message; }
});
async function loadAdmin() {
  const [summary, list] = await Promise.all([api("/api/admin/summary"), api("/api/admin/users")]);
  $("countUsers").textContent = summary.stats.users;
  $("countActive").textContent = summary.stats.active;
  $("countSuspended").textContent = summary.stats.suspended;
  renderUsers(list.users);
  $("events").replaceChildren();
  for (const event of summary.events) {
    const div = document.createElement("div");
    div.className = "event";
    div.textContent = `${event.created_at} — ${event.event_type} — ${event.email || "النظام"}${event.details ? " — " + event.details : ""}`;
    $("events").appendChild(div);
  }
}
function renderUsers(users) {
  const tbody = $("usersBody"); tbody.replaceChildren();
  if (!users.length) {
    const tr = document.createElement("tr"), td = document.createElement("td");
    td.colSpan = 4; td.textContent = "لا توجد حسابات مطابقة."; tr.appendChild(td); tbody.appendChild(tr); return;
  }
  for (const user of users) {
    const tr = document.createElement("tr");
    const name = document.createElement("td"); name.textContent = user.name;
    const email = document.createElement("td"); email.textContent = user.email;
    const status = document.createElement("td"); status.textContent = user.status === "active" ? "نشط" : "موقوف"; status.className = user.status === "active" ? "status-active" : "status-suspended";
    const actionCell = document.createElement("td"), btn = document.createElement("button");
    btn.className = user.status === "active" ? "danger small" : "secondary small";
    btn.textContent = user.status === "active" ? "إيقاف" : "تفعيل";
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      try {
        await api(`/api/admin/users/${user.id}/status`, "POST", { status: user.status === "active" ? "suspended" : "active" });
        await loadAdmin(); message("تم تحديث حالة الحساب.");
      } catch (err) { message(err.message, true); }
      finally { btn.disabled = false; }
    });
    actionCell.appendChild(btn); tr.append(name, email, status, actionCell); tbody.appendChild(tr);
  }
}
let searchTimer;
$("searchUsers").addEventListener("input", () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(async () => {
    if (!currentUser || currentUser.role !== "admin") return;
    try { const d = await api(`/api/admin/users?q=${encodeURIComponent($("searchUsers").value)}`); renderUsers(d.users); }
    catch (e) { message(e.message, true); }
  }, 250);
});
$("adminRefresh").addEventListener("click", () => loadAdmin().then(() => message("تم تحديث لوحة المدير.")).catch(e => message(e.message, true)));
(async function init() {
  try {
    await getCsrf();
    const config = await api("/api/config");
    if (!config.localAdminSetupEnabled) $("setupForm").classList.add("hidden");
    const d = await api("/api/auth/me");
    if (d.user) renderUser(d.user);
  } catch (e) { message("تعذر الاتصال بالخادم. شغّل المشروع ثم حدّث الصفحة.", true); }
})();
